import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        void: '#0A0A12',
        panel: '#13121C',
        jacket: '#1C1B29',
        gold: '#D4AF6A',
        'gold-dim': '#8A734A',
        glow: '#8FE3D1',
        'glow-soft': '#4FA897',
        skin: '#F4EFE6',
        border: '#25233A',
      },
      fontFamily: {
        serif: ['"DM Serif Display"', 'serif'],
        sans: ['"DM Sans"', 'sans-serif'],
      },
      backgroundImage: {
        'glow-radial': 'radial-gradient(circle at 50% 20%, #1a1830 0%, #0A0A12 60%)',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '0.55' },
          '50%': { opacity: '1' },
        },
      },
      animation: {
        pulseGlow: 'pulseGlow 2.6s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
