import { create } from 'zustand';

export interface PlayerTrack {
  id: string;
  title: string;
  artistName: string;
  coverUrl: string;
  mood: string;
  durationSec: number;
}

interface PlayerState {
  current: PlayerTrack | null;
  queue: PlayerTrack[];
  isPlaying: boolean;
  progressSec: number;
  play: (track: PlayerTrack, queue?: PlayerTrack[]) => void;
  toggle: () => void;
  setProgress: (sec: number) => void;
  next: () => void;
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  current: null,
  queue: [],
  isPlaying: false,
  progressSec: 0,
  play: (track, queue) => set({ current: track, queue: queue ?? get().queue, isPlaying: true, progressSec: 0 }),
  toggle: () => set({ isPlaying: !get().isPlaying }),
  setProgress: (sec) => set({ progressSec: sec }),
  next: () => {
    const { queue, current } = get();
    if (!current || queue.length === 0) return;
    const idx = queue.findIndex((t) => t.id === current.id);
    const nextTrack = queue[(idx + 1) % queue.length];
    set({ current: nextTrack, progressSec: 0, isPlaying: true });
  },
}));
