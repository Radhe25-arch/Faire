export type MoodKey = 'CHILL' | 'HYPE' | 'HEARTBREAK' | 'POWER_UP' | 'RAGE';

export interface MoodConfig {
  label: string;
  pose: string;
  accent: string;
  filter: string;
  bgGradient: string;
  description: string;
}

export const MOOD_MAP: Record<MoodKey, MoodConfig> = {
  CHILL: {
    label: 'Chill',
    pose: '/mascot/chill.png',
    accent: '#8FE3D1',
    filter: 'none',
    bgGradient: 'radial-gradient(ellipse at bottom, rgba(143,227,209,0.12) 0%, transparent 70%)',
    description: 'Relaxed, chin touch — moon-glow steady.',
  },
  HEARTBREAK: {
    label: 'Heartbreak',
    pose: '/mascot/heartbreak.png',
    accent: '#7A8AC9',
    filter: 'saturate(0.75) brightness(0.88)',
    bgGradient: 'radial-gradient(ellipse at bottom, rgba(122,138,201,0.14) 0%, transparent 70%)',
    description: 'Crouched low, gaze hollow, glow dimmed.',
  },
  HYPE: {
    label: 'Hype',
    pose: '/mascot/hype.png',
    accent: '#D4AF6A',
    filter: 'saturate(1.25) contrast(1.1) brightness(1.06)',
    bgGradient: 'radial-gradient(ellipse at bottom, rgba(212,175,106,0.15) 0%, transparent 70%)',
    description: 'Standing tall, gold light rising.',
  },
  POWER_UP: {
    label: 'Power Up',
    pose: '/mascot/power_up.png',
    accent: '#8FE3D1',
    filter: 'saturate(1.4) contrast(1.15) brightness(1.08)',
    bgGradient: 'radial-gradient(ellipse at bottom, rgba(143,227,209,0.18) 0%, transparent 60%)',
    description: 'Side profile, crescent emblem igniting.',
  },
  RAGE: {
    label: 'Rage',
    pose: '/mascot/rage.png',
    accent: '#C9586A',
    filter: 'saturate(1.5) contrast(1.25) hue-rotate(-20deg)',
    bgGradient: 'radial-gradient(ellipse at bottom, rgba(201,88,106,0.18) 0%, transparent 60%)',
    description: 'Back turned, 혼 emblem blazing.',
  },
};

export function getMoodConfig(mood: string): MoodConfig {
  return MOOD_MAP[mood as MoodKey] ?? MOOD_MAP.CHILL;
}
