'use client';
import { usePlayerStore } from '@/lib/store';
import { getMoodConfig } from '@/lib/moodTagger';
import Image from 'next/image';
import Link from 'next/link';

export default function MiniPlayer() {
  const { current, isPlaying, toggle, progressSec } = usePlayerStore();
  if (!current) return null;

  const mood = getMoodConfig(current.mood);
  const pct = Math.min((progressSec / current.durationSec) * 100, 100);

  return (
    <div className="fixed bottom-16 inset-x-0 z-40 px-3 pb-2">
      <div className="max-w-lg mx-auto rounded-2xl border border-border overflow-hidden"
           style={{ background: 'rgba(19,18,28,0.96)', backdropFilter: 'blur(20px)' }}>
        {/* Progress bar */}
        <div className="h-0.5 bg-border">
          <div className="h-full bg-glow transition-all duration-1000" style={{ width: `${pct}%` }} />
        </div>

        <Link href="/now-playing" className="flex items-center gap-3 px-4 py-3">
          {/* Cover */}
          <div className="w-10 h-10 rounded-lg overflow-hidden relative flex-shrink-0 border border-border">
            <Image src={current.coverUrl || '/mascot/portrait.png'} alt="" fill className="object-cover" />
          </div>

          {/* Track info */}
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-skin truncate">{current.title}</div>
            <div className="text-xs text-skin/50 truncate">{current.artistName}</div>
          </div>

          {/* Mood accent dot */}
          <div className="w-2 h-2 rounded-full flex-shrink-0 animate-pulseGlow"
               style={{ background: mood.accent, boxShadow: `0 0 6px ${mood.accent}` }} />

          {/* Play/Pause */}
          <button onClick={(e) => { e.preventDefault(); toggle(); }}
            className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-skin hover:border-glow transition-colors flex-shrink-0">
            <span className="text-base leading-none">{isPlaying ? '⏸' : '▶'}</span>
          </button>
        </Link>
      </div>
    </div>
  );
}
