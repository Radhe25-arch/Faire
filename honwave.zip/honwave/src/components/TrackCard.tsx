'use client';
import Image from 'next/image';
import { usePlayerStore, PlayerTrack } from '@/lib/store';
import { getMoodConfig } from '@/lib/moodTagger';

interface TrackCardProps {
  track: {
    id: string;
    title: string;
    mood: string;
    durationSec: number;
    coverUrl?: string | null;
    artist: { name: string };
    genreTag?: string | null;
    isNewDrop?: boolean;
  };
  queue?: PlayerTrack[];
  compact?: boolean;
}

function fmtSec(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

export default function TrackCard({ track, queue, compact }: TrackCardProps) {
  const { play, current, isPlaying } = usePlayerStore();
  const mood = getMoodConfig(track.mood);
  const isActive = current?.id === track.id;

  const playerTrack: PlayerTrack = {
    id: track.id,
    title: track.title,
    artistName: track.artist.name,
    coverUrl: track.coverUrl || '/mascot/portrait.png',
    mood: track.mood,
    durationSec: track.durationSec,
  };

  return (
    <button onClick={() => play(playerTrack, queue)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-left
        ${isActive ? 'bg-jacket border border-glow/30' : 'hover:bg-jacket/60 border border-transparent'}`}>

      <div className="relative w-11 h-11 rounded-lg overflow-hidden flex-shrink-0">
        <Image src={track.coverUrl || '/mascot/portrait.png'} alt="" fill className="object-cover" />
        {isActive && (
          <div className="absolute inset-0 bg-void/50 flex items-center justify-center">
            <span className="text-glow text-lg">{isPlaying ? '⏸' : '▶'}</span>
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0">
        <div className={`text-sm font-medium truncate ${isActive ? 'text-glow' : 'text-skin'}`}>
          {track.title}
        </div>
        <div className="text-xs text-skin/50 truncate">{track.artist.name}</div>
      </div>

      {!compact && (
        <div className="flex items-center gap-2 flex-shrink-0">
          {track.isNewDrop && (
            <span className="text-[9px] bg-gold/20 text-gold border border-gold/30 rounded px-1.5 py-0.5 font-bold tracking-wider">NEW</span>
          )}
          <div className="w-1.5 h-1.5 rounded-full" style={{ background: mood.accent }} />
          <span className="text-xs text-skin/40">{fmtSec(track.durationSec)}</span>
        </div>
      )}
    </button>
  );
}
