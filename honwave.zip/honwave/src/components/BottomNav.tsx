'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const TABS = [
  { href: '/home',        label: 'Home',    icon: '⌂' },
  { href: '/search',      label: 'Search',  icon: '◎' },
  { href: '/library',     label: 'Library', icon: '≡' },
  { href: '/settings',    label: 'You',     icon: '○' },
];

export default function BottomNav() {
  const path = usePathname();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 border-t border-border"
         style={{ background: 'rgba(10,10,18,0.92)', backdropFilter: 'blur(16px)' }}>
      <div className="flex items-center justify-around max-w-lg mx-auto h-16 px-4">
        {TABS.map(({ href, label, icon }) => {
          const active = path.startsWith(href);
          return (
            <Link key={href} href={href}
              className={`flex flex-col items-center gap-0.5 min-w-[60px] transition-all duration-200 ${
                active ? 'text-glow' : 'text-skin/40 hover:text-skin/70'
              }`}>
              <span className="text-xl leading-none">{icon}</span>
              <span className="text-[10px] tracking-wider font-medium">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
