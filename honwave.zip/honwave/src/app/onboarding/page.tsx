'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

const GENRES = ['K-pop', 'Anime OST', 'Lo-fi Manhwa', 'City Pop', 'Dark Trap', 'R&B'];
const VIBES = ['Mysterious', 'Calm', 'Focused', 'Melancholic', 'Creative', 'Untouchable'];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [genres, setGenres] = useState<string[]>([]);
  const [vibes, setVibes] = useState<string[]>([]);

  function toggle(arr: string[], setArr: (a: string[]) => void, val: string) {
    setArr(arr.includes(val) ? arr.filter(v => v !== val) : [...arr, val]);
  }

  async function finish() {
    await fetch('/api/onboarding', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ genres }),
    });
    router.push('/home');
  }

  const steps = [
    {
      title: 'What moves you?',
      sub: 'Pick your genres',
      items: GENRES,
      selected: genres,
      toggle: (v: string) => toggle(genres, setGenres, v),
    },
    {
      title: 'Your vibe is?',
      sub: 'Pick your energy',
      items: VIBES,
      selected: vibes,
      toggle: (v: string) => toggle(vibes, setVibes, v),
    },
  ];

  const current = steps[step];

  return (
    <div className="min-h-screen bg-void flex flex-col items-center justify-center px-4 py-12"
         style={{ background: 'radial-gradient(circle at 50% 10%, #1a1830 0%, #0A0A12 60%)' }}>

      {/* HON mascot top */}
      <div className="mb-8 w-[140px] h-[160px] relative">
        <Image src="/mascot/chill.png" alt="HON" fill className="object-contain object-bottom"
          style={{ filter: 'drop-shadow(0 0 30px rgba(143,227,209,0.4))' }} />
      </div>

      <div className="w-full max-w-[420px]">
        {/* Progress */}
        <div className="flex gap-2 mb-8">
          {steps.map((_, i) => (
            <div key={i} className={`h-1 flex-1 rounded-full transition-all duration-500 ${i <= step ? 'bg-glow' : 'bg-border'}`} />
          ))}
        </div>

        <div className="text-center mb-8">
          <div className="text-xs text-glow tracking-[0.3em] uppercase mb-2">{current.sub}</div>
          <h1 className="font-serif text-3xl text-skin">{current.title}</h1>
        </div>

        <div className="flex flex-wrap gap-3 justify-center mb-10">
          {current.items.map(item => {
            const active = current.selected.includes(item);
            return (
              <button key={item} onClick={() => current.toggle(item)}
                className={`px-4 py-2 rounded-full border text-sm font-medium transition-all duration-200 ${
                  active
                    ? 'bg-glow text-void border-glow'
                    : 'bg-panel border-border text-skin/60 hover:border-glow/50 hover:text-skin'
                }`}>
                {item}
              </button>
            );
          })}
        </div>

        <div className="flex gap-3">
          {step > 0 && (
            <button onClick={() => setStep(step - 1)}
              className="flex-1 py-3 rounded-xl border border-border text-sm text-skin/60 hover:text-skin transition-all">
              Back
            </button>
          )}
          <button
            onClick={step === steps.length - 1 ? finish : () => setStep(step + 1)}
            disabled={current.selected.length === 0}
            className="flex-1 py-3 rounded-xl bg-glow text-void font-bold text-sm hover:brightness-110 transition-all disabled:opacity-40">
            {step === steps.length - 1 ? 'Start Listening' : 'Continue'}
          </button>
        </div>

        <button onClick={() => router.push('/home')} className="w-full mt-4 text-xs text-skin/30 hover:text-skin/50 transition-colors">
          Skip for now
        </button>
      </div>
    </div>
  );
}
