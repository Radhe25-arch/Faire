import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const userId = (session.user as any).id as string;
  const { genres } = await req.json();

  for (const name of genres as string[]) {
    const genre = await prisma.genre.upsert({ where: { name }, update: {}, create: { name } });
    await prisma.userGenre.upsert({
      where: { userId_genreId: { userId, genreId: genre.id } },
      update: {},
      create: { userId, genreId: genre.id },
    });
  }

  return NextResponse.json({ ok: true });
}
