import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mood = searchParams.get('mood');
  const newDrops = searchParams.get('newDrops') === 'true';
  const search = searchParams.get('q');
  const limit = parseInt(searchParams.get('limit') || '20');

  const tracks = await prisma.track.findMany({
    where: {
      ...(mood ? { mood: mood as any } : {}),
      ...(newDrops ? { isNewDrop: true } : {}),
      ...(search ? {
        OR: [
          { title: { contains: search } },
          { artist: { name: { contains: search } } },
          { genreTag: { contains: search } },
        ]
      } : {}),
    },
    include: { artist: true, album: true },
    orderBy: { playCount: 'desc' },
    take: limit,
  });

  return NextResponse.json(tracks);
}
