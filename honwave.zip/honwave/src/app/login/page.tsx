'use client';
import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

export default function LoginPage() {
  const router = useRouter();
  const [tab, setTab] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleCredentials() {
    setLoading(true);
    setError('');

    if (tab === 'signup') {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name }),
      });
      if (!res.ok) {
        const d = await res.json();
        setError(d.error || 'Signup failed');
        setLoading(false);
        return;
      }
    }

    const result = await signIn('credentials', { email, password, redirect: false });
    if (result?.error) {
      setError('Invalid email or password');
      setLoading(false);
      return;
    }
    router.push('/onboarding');
  }

  async function handleGuest() {
    setLoading(true);
    await signIn('guest', { redirect: false });
    router.push('/home');
  }

  return (
    <div className="min-h-screen bg-void flex items-center justify-center px-4"
         style={{ background: 'radial-gradient(circle at 50% 20%, #1a1830 0%, #0A0A12 60%)' }}>

      {/* Mascot */}
      <div className="hidden lg:block absolute left-[8vw] bottom-0 w-[280px] opacity-90 pointer-events-none select-none">
        <Image src="/mascot/chill.png" alt="HON" width={280} height={400} className="object-contain" style={{ filter: 'drop-shadow(0 0 40px rgba(143,227,209,0.3))' }} />
      </div>

      <div className="w-full max-w-[380px] space-y-6">
        {/* Logo */}
        <div className="text-center space-y-1">
          <div className="text-4xl font-serif text-skin tracking-tight">혼WAVE</div>
          <div className="text-xs text-glow tracking-[0.3em] uppercase">Seoul · Music · Soul</div>
        </div>

        {/* Tabs */}
        <div className="flex bg-panel rounded-xl p-1 border border-border">
          {(['login', 'signup'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${tab === t ? 'bg-jacket text-skin' : 'text-skin/40 hover:text-skin/70'}`}>
              {t === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          ))}
        </div>

        {/* Form */}
        <div className="bg-panel border border-border rounded-2xl p-6 space-y-4">
          {tab === 'signup' && (
            <input value={name} onChange={e => setName(e.target.value)}
              placeholder="Name"
              className="w-full bg-jacket border border-border rounded-xl px-4 py-3 text-sm text-skin placeholder-skin/30 outline-none focus:border-glow transition-colors" />
          )}
          <input value={email} onChange={e => setEmail(e.target.value)}
            placeholder="Email" type="email"
            className="w-full bg-jacket border border-border rounded-xl px-4 py-3 text-sm text-skin placeholder-skin/30 outline-none focus:border-glow transition-colors" />
          <input value={password} onChange={e => setPassword(e.target.value)}
            placeholder="Password" type="password"
            className="w-full bg-jacket border border-border rounded-xl px-4 py-3 text-sm text-skin placeholder-skin/30 outline-none focus:border-glow transition-colors" />

          {error && <p className="text-red-400 text-xs">{error}</p>}

          <button onClick={handleCredentials} disabled={loading}
            className="w-full py-3 rounded-xl bg-glow text-void font-bold text-sm hover:brightness-110 transition-all disabled:opacity-50">
            {loading ? '...' : tab === 'login' ? 'Sign In' : 'Create Account'}
          </button>

          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-skin/30">or</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <button onClick={() => signIn('google', { callbackUrl: '/onboarding' })}
            className="w-full py-3 rounded-xl border border-border text-sm text-skin/70 hover:border-gold hover:text-skin transition-all">
            Continue with Google
          </button>

          <button onClick={handleGuest}
            className="w-full py-3 rounded-xl border border-border text-sm text-skin/40 hover:text-skin/70 transition-all">
            Enter as Guest
          </button>
        </div>

        {tab === 'login' && (
          <p className="text-center text-xs text-skin/30">
            Demo: <span className="text-gold">demo@honwave.app</span> / password123
          </p>
        )}
      </div>
    </div>
  );
}
