import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import LibraryClient from './LibraryClient';

export default async function LibraryPage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string;

  const [liked, playlists, recent] = await Promise.all([
    prisma.likedSong.findMany({
      where: { userId },
      include: { track: { include: { artist: true } } },
      orderBy: { likedAt: 'desc' },
      take: 30,
    }),
    prisma.playlist.findMany({
      where: { userId },
      include: { _count: { select: { tracks: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.recentlyPlayed.findMany({
      where: { userId },
      include: { track: { include: { artist: true } } },
      orderBy: { playedAt: 'desc' },
      take: 20,
    }),
  ]);

  return (
    <LibraryClient
      liked={JSON.parse(JSON.stringify(liked))}
      playlists={JSON.parse(JSON.stringify(playlists))}
      recent={JSON.parse(JSON.stringify(recent))}
    />
  );
}
