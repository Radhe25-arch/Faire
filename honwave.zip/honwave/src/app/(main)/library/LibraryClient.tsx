'use client';
import { useState } from 'react';
import TrackCard from '@/components/TrackCard';
import { PlayerTrack } from '@/lib/store';

const TABS = ['Liked', 'Playlists', 'Recent'] as const;

interface LikedSong { id: string; track: Track; }
interface Playlist { id: string; title: string; coverUrl?: string | null; _count: { tracks: number }; }
interface Recent { id: string; track: Track; }
interface Track { id: string; title: string; mood: string; durationSec: number; coverUrl?: string | null; isNewDrop?: boolean; artist: { id: string; name: string }; }

function toPlayerTrack(t: Track): PlayerTrack {
  return { id: t.id, title: t.title, artistName: t.artist.name, coverUrl: t.coverUrl || '/mascot/portrait.png', mood: t.mood, durationSec: t.durationSec };
}

export default function LibraryClient({ liked, playlists, recent }: { liked: LikedSong[]; playlists: Playlist[]; recent: Recent[]; }) {
  const [tab, setTab] = useState<typeof TABS[number]>('Liked');

  return (
    <div className="min-h-screen bg-void px-5 pt-14 pb-4">
      <h1 className="font-serif text-3xl text-skin mb-6">Library</h1>

      {/* Tabs */}
      <div className="flex gap-1 bg-panel rounded-xl p-1 border border-border mb-6">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2 rounded-lg text-xs font-bold tracking-wider uppercase transition-all ${tab === t ? 'bg-jacket text-skin' : 'text-skin/40'}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Liked' && (
        <div>
          <div className="text-xs text-skin/30 mb-3">{liked.length} songs</div>
          {liked.length === 0
            ? <EmptyState msg="Like songs to see them here." />
            : <div className="space-y-1">{liked.map(l => <TrackCard key={l.id} track={l.track} queue={liked.map(l => toPlayerTrack(l.track))} />)}</div>
          }
        </div>
      )}

      {tab === 'Playlists' && (
        <div>
          {playlists.length === 0
            ? <EmptyState msg="No playlists yet." />
            : (
              <div className="space-y-3">
                {playlists.map(p => (
                  <div key={p.id} className="flex items-center gap-4 px-4 py-3 rounded-xl border border-border bg-panel">
                    <div className="w-12 h-12 rounded-lg bg-jacket border border-border flex items-center justify-center text-gold text-xl">♩</div>
                    <div>
                      <div className="text-sm font-medium text-skin">{p.title}</div>
                      <div className="text-xs text-skin/40">{p._count.tracks} tracks</div>
                    </div>
                  </div>
                ))}
              </div>
            )
          }
        </div>
      )}

      {tab === 'Recent' && (
        <div>
          {recent.length === 0
            ? <EmptyState msg="Nothing played yet." />
            : <div className="space-y-1">{recent.map(r => <TrackCard key={r.id} track={r.track} queue={recent.map(r => toPlayerTrack(r.track))} />)}</div>
          }
        </div>
      )}
    </div>
  );
}

function EmptyState({ msg }: { msg: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-2 text-skin/30">
      <span className="text-4xl">🌙</span>
      <span className="text-sm">{msg}</span>
    </div>
  );
}
