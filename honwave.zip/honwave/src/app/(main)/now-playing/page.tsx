'use client';
import { usePlayerStore } from '@/lib/store';
import { getMoodConfig } from '@/lib/moodTagger';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useState, useRef } from 'react';

function fmtSec(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

// Simulated lyric lines
const DEMO_LYRICS = [
  'born in the silence of Seoul',
  '불빛 아래 혼자 서 있어',
  'crescent mark still burning',
  '네 목소리가 사라져',
  'static in the frequency',
  '혼이 울고 있어 (hon-i ulgo isseo)',
  'I live in the noise to protect my silence',
  '달빛 아래 우리 다시',
];

export default function NowPlayingPage() {
  const router = useRouter();
  const { current, isPlaying, toggle, progressSec, setProgress, next, queue } = usePlayerStore();
  const [liked, setLiked] = useState(false);
  const [showStory, setShowStory] = useState(false);
  const storyRef = useRef<HTMLDivElement>(null);

  if (!current) {
    return (
      <div className="min-h-screen bg-void flex flex-col items-center justify-center gap-4 text-skin/30">
        <div className="text-5xl">🌙</div>
        <div className="text-sm">Nothing playing yet.</div>
        <button onClick={() => router.push('/home')} className="text-xs text-glow underline">Go to Home</button>
      </div>
    );
  }

  const mood = getMoodConfig(current.mood);
  const pct = Math.min((progressSec / current.durationSec) * 100, 100);
  const activeLyricIdx = Math.floor((progressSec / current.durationSec) * DEMO_LYRICS.length);

  async function exportStory() {
    if (typeof window === 'undefined') return;
    const { toBlob } = await import('html-to-image');
    if (!storyRef.current) return;
    const blob = await toBlob(storyRef.current, { cacheBust: true });
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `honwave-story-${current.title}.png`; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-void flex flex-col" style={{ background: `radial-gradient(ellipse at 50% 0%, rgba(${mood.accent === '#8FE3D1' ? '143,227,209' : mood.accent === '#D4AF6A' ? '212,175,106' : mood.accent === '#7A8AC9' ? '122,138,201' : '201,88,106'},0.12) 0%, #0A0A12 55%)` }}>

      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-14 pb-4">
        <button onClick={() => router.back()} className="text-skin/60 hover:text-skin text-xl">↓</button>
        <div className="text-xs tracking-widest text-skin/40 uppercase">Now Playing</div>
        <button className="text-skin/60 hover:text-skin">⋮</button>
      </div>

      {/* Mascot — full height, mood-driven */}
      <div className="relative flex-shrink-0 h-[280px] mx-auto w-full max-w-[340px]">
        <Image
          src={mood.pose}
          alt={`HON — ${mood.label}`}
          fill
          className="object-contain object-bottom transition-all duration-700"
          style={{ filter: `${mood.filter} drop-shadow(0 0 50px ${mood.accent}60)` }}
          priority
        />
        {/* Mood label badge */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full border text-[10px] font-bold tracking-widest uppercase"
             style={{ borderColor: `${mood.accent}60`, color: mood.accent, background: `${mood.accent}10` }}>
          {mood.label}
        </div>
      </div>

      {/* Track info + controls */}
      <div className="flex-1 px-5 pt-4 pb-8 space-y-6">

        {/* Title row */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-serif text-2xl text-skin leading-tight">{current.title}</h2>
            <div className="text-sm text-skin/50 mt-0.5">{current.artistName}</div>
          </div>
          <button onClick={() => setLiked(!liked)}
            className={`mt-1 text-2xl transition-all duration-200 ${liked ? 'text-gold scale-110' : 'text-skin/30 hover:text-skin/60'}`}>
            {liked ? '♥' : '♡'}
          </button>
        </div>

        {/* Progress bar */}
        <div className="space-y-1.5">
          <div className="relative h-1 bg-border rounded-full cursor-pointer"
               onClick={(e) => {
                 const rect = e.currentTarget.getBoundingClientRect();
                 const ratio = (e.clientX - rect.left) / rect.width;
                 setProgress(ratio * current.durationSec);
               }}>
            <div className="absolute inset-y-0 left-0 rounded-full transition-all duration-300"
                 style={{ width: `${pct}%`, background: mood.accent }} />
            <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full border-2 border-void -translate-x-1/2"
                 style={{ left: `${pct}%`, background: mood.accent }} />
          </div>
          <div className="flex justify-between text-[10px] text-skin/30">
            <span>{fmtSec(progressSec)}</span>
            <span>{fmtSec(current.durationSec)}</span>
          </div>
        </div>

        {/* Playback controls */}
        <div className="flex items-center justify-between px-4">
          <button className="text-skin/30 hover:text-skin text-xl transition-colors">⇄</button>
          <button className="text-skin/50 hover:text-skin text-2xl transition-colors">⏮</button>
          <button onClick={toggle}
            className="w-14 h-14 rounded-full flex items-center justify-center text-void text-xl font-bold shadow-lg transition-all hover:scale-105"
            style={{ background: mood.accent }}>
            {isPlaying ? '⏸' : '▶'}
          </button>
          <button onClick={next} className="text-skin/50 hover:text-skin text-2xl transition-colors">⏭</button>
          <button className="text-skin/30 hover:text-skin text-xl transition-colors">↻</button>
        </div>

        {/* Lyrics preview */}
        <div className="space-y-2 py-2 max-h-40 overflow-hidden">
          {DEMO_LYRICS.map((line, i) => (
            <div key={i} className={`text-sm transition-all duration-500 ${i === activeLyricIdx ? 'text-skin font-medium scale-100' : 'text-skin/25 scale-95'}`}>
              {line}
            </div>
          ))}
        </div>

        {/* Story export */}
        <button onClick={() => setShowStory(true)}
          className="w-full py-3 rounded-xl border border-gold/40 text-gold text-sm font-bold hover:bg-gold/10 transition-all">
          ✦ Share to Story
        </button>
      </div>

      {/* Story export modal */}
      {showStory && (
        <div className="fixed inset-0 z-50 bg-void/90 flex flex-col items-center justify-center gap-6 px-6">
          {/* 9:16 Story Card */}
          <div ref={storyRef}
               className="relative w-[260px] h-[460px] rounded-3xl overflow-hidden flex flex-col items-center justify-end pb-8"
               style={{ background: `linear-gradient(180deg, #0A0A12 0%, #1C1B29 100%)` }}>
            {/* speed lines bg */}
            <div className="absolute inset-0 opacity-10"
                 style={{ background: `repeating-linear-gradient(${Math.random() * 20 + 80}deg, transparent, transparent 8px, ${mood.accent}30 8px, ${mood.accent}30 9px)` }} />
            {/* Mascot */}
            <div className="absolute inset-0 flex items-end justify-center pb-28">
              <div className="relative w-[180px] h-[240px]">
                <Image src={mood.pose} alt="" fill className="object-contain object-bottom"
                  style={{ filter: `drop-shadow(0 0 40px ${mood.accent}80)` }} />
              </div>
            </div>
            {/* Track info */}
            <div className="relative z-10 text-center px-4">
              <div className="text-xs tracking-[0.3em] mb-1" style={{ color: mood.accent }}>혼WAVE</div>
              <div className="font-serif text-lg text-skin">{current.title}</div>
              <div className="text-xs text-skin/50">{current.artistName}</div>
              {/* Progress bar */}
              <div className="mt-3 h-0.5 w-full bg-border rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${pct}%`, background: mood.accent }} />
              </div>
            </div>
            {/* Watermark */}
            <div className="absolute top-4 right-4 text-[10px] text-skin/30 tracking-widest">혼</div>
          </div>

          <div className="flex gap-3 w-full max-w-[260px]">
            <button onClick={() => setShowStory(false)}
              className="flex-1 py-3 rounded-xl border border-border text-sm text-skin/60">Cancel</button>
            <button onClick={exportStory}
              className="flex-1 py-3 rounded-xl text-void text-sm font-bold"
              style={{ background: mood.accent }}>Save PNG</button>
          </div>

          <p className="text-[10px] text-skin/20 text-center max-w-[220px]">
            Free tier includes 혼WAVE watermark.<br/>Upgrade to Premium for animated exports.
          </p>
        </div>
      )}
    </div>
  );
}
