'use client';
import { useState, useEffect } from 'react';
import TrackCard from '@/components/TrackCard';
import { PlayerTrack } from '@/lib/store';
import { getMoodConfig } from '@/lib/moodTagger';

const GENRES = ['K-pop', 'Anime OST', 'Lo-fi Manhwa', 'City Pop', 'Dark Trap', 'R&B'];
const MOODS = ['CHILL', 'HYPE', 'HEARTBREAK', 'POWER_UP', 'RAGE'] as const;

interface Track { id: string; title: string; mood: string; durationSec: number; coverUrl?: string | null; isNewDrop?: boolean; artist: { id: string; name: string }; }

function toPlayerTrack(t: Track): PlayerTrack {
  return { id: t.id, title: t.title, artistName: t.artist.name, coverUrl: t.coverUrl || '/mascot/portrait.png', mood: t.mood, durationSec: t.durationSec };
}

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const t = setTimeout(async () => {
      setLoading(true);
      const res = await fetch(`/api/songs?q=${encodeURIComponent(query)}&limit=20`);
      const data = await res.json();
      setResults(data);
      setLoading(false);
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <div className="min-h-screen bg-void px-5 pt-14 pb-4">
      <h1 className="font-serif text-3xl text-skin mb-6">Search</h1>

      {/* Search input */}
      <div className="relative mb-6">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-skin/30">◎</span>
        <input value={query} onChange={e => setQuery(e.target.value)}
          placeholder="Songs, artists, genres..."
          className="w-full bg-panel border border-border rounded-2xl pl-10 pr-4 py-3.5 text-sm text-skin placeholder-skin/30 outline-none focus:border-glow transition-colors" />
        {query && (
          <button onClick={() => setQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-skin/30 hover:text-skin">✕</button>
        )}
      </div>

      {query ? (
        /* Results */
        <div>
          <div className="text-xs text-skin/40 mb-3 uppercase tracking-widest">
            {loading ? 'Searching...' : `${results.length} results`}
          </div>
          <div className="space-y-1">
            {results.map(t => <TrackCard key={t.id} track={t} queue={results.map(toPlayerTrack)} />)}
          </div>
          {!loading && results.length === 0 && (
            <div className="text-center py-16 text-skin/30 text-sm">No results for "{query}"</div>
          )}
        </div>
      ) : (
        /* Browse */
        <div className="space-y-8">
          <div>
            <div className="text-xs font-bold tracking-widest text-skin/60 uppercase mb-4">Browse by Mood</div>
            <div className="grid grid-cols-2 gap-3">
              {MOODS.map(m => {
                const mc = getMoodConfig(m);
                return (
                  <button key={m} onClick={() => setQuery(m)}
                    className="relative rounded-2xl border border-border overflow-hidden px-4 py-5 text-left group hover:border-glow/50 transition-all">
                    <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity"
                         style={{ background: mc.bgGradient }} />
                    <div className="relative">
                      <div className="font-serif text-lg text-skin mb-0.5">{mc.label}</div>
                      <div className="text-[10px] tracking-wider" style={{ color: mc.accent }}>
                        {m.replace('_', ' ')}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="text-xs font-bold tracking-widest text-skin/60 uppercase mb-4">Browse by Genre</div>
            <div className="flex flex-wrap gap-2">
              {GENRES.map(g => (
                <button key={g} onClick={() => setQuery(g)}
                  className="px-4 py-2 rounded-full border border-border text-sm text-skin/60 hover:border-gold hover:text-gold transition-all">
                  {g}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
