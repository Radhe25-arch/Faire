import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import BottomNav from '@/components/BottomNav';
import MiniPlayer from '@/components/MiniPlayer';

export default async function MainLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/login');

  return (
    <div className="min-h-screen bg-void flex flex-col">
      <main className="flex-1 overflow-y-auto pb-40">{children}</main>
      <MiniPlayer />
      <BottomNav />
    </div>
  );
}
