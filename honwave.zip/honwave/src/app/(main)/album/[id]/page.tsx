import { prisma } from '@/lib/prisma';
import Image from 'next/image';
import TrackCard from '@/components/TrackCard';
import { PlayerTrack } from '@/lib/store';
import { notFound } from 'next/navigation';
import Link from 'next/link';

function toPlayerTrack(t: any): PlayerTrack {
  return { id: t.id, title: t.title, artistName: t.artist?.name || '', coverUrl: t.coverUrl || '/mascot/portrait.png', mood: t.mood, durationSec: t.durationSec };
}

export default async function AlbumPage({ params }: { params: { id: string } }) {
  const album = await prisma.album.findUnique({
    where: { id: params.id },
    include: {
      artist: true,
      tracks: { include: { artist: true }, orderBy: { id: 'asc' } },
    },
  });
  if (!album) notFound();

  const queue = album.tracks.map(toPlayerTrack);
  const totalSec = album.tracks.reduce((s, t) => s + t.durationSec, 0);
  const totalMin = Math.floor(totalSec / 60);

  return (
    <div className="min-h-screen bg-void pb-4">
      {/* Header */}
      <div className="px-5 pt-14 pb-6 flex gap-5 items-end">
        <div className="relative w-28 h-28 rounded-2xl overflow-hidden border border-border flex-shrink-0 shadow-2xl">
          <Image src={album.coverUrl || '/mascot/sitting.png'} alt="" fill className="object-cover" />
        </div>
        <div className="min-w-0">
          <div className="text-[10px] text-skin/30 uppercase tracking-widest mb-1">Album</div>
          <h1 className="font-serif text-2xl text-skin leading-tight">{album.title}</h1>
          <Link href={`/artist/${album.artist.id}`} className="text-sm text-gold hover:underline">{album.artist.name}</Link>
          <div className="text-xs text-skin/30 mt-1">
            {album.tracks.length} tracks · {totalMin} min
            {album.releaseDate && ` · ${new Date(album.releaseDate).getFullYear()}`}
          </div>
        </div>
      </div>

      {/* Tracklist */}
      <div className="space-y-1">
        {album.tracks.map((t, i) => (
          <div key={t.id} className="flex items-center gap-2 px-3">
            <span className="text-xs text-skin/20 w-5 text-right flex-shrink-0">{i + 1}</span>
            <div className="flex-1 min-w-0">
              <TrackCard track={t} queue={queue} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
