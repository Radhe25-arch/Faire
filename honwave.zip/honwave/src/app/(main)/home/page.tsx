import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import HomeClient from './HomeClient';

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;

  const [newDrops, trending, allTracks] = await Promise.all([
    prisma.track.findMany({
      where: { isNewDrop: true },
      include: { artist: true, album: true },
      orderBy: { createdAt: 'desc' },
      take: 8,
    }),
    prisma.track.findMany({
      include: { artist: true, album: true },
      orderBy: { playCount: 'desc' },
      take: 10,
    }),
    prisma.track.findMany({
      include: { artist: true, album: true },
      take: 30,
    }),
  ]);

  const moodShelves: Record<string, typeof allTracks> = {
    CHILL: allTracks.filter(t => t.mood === 'CHILL'),
    HYPE: allTracks.filter(t => t.mood === 'HYPE'),
    HEARTBREAK: allTracks.filter(t => t.mood === 'HEARTBREAK'),
  };

  return (
    <HomeClient
      newDrops={JSON.parse(JSON.stringify(newDrops))}
      trending={JSON.parse(JSON.stringify(trending))}
      moodShelves={JSON.parse(JSON.stringify(moodShelves))}
      allTracks={JSON.parse(JSON.stringify(allTracks))}
      userName={session?.user?.name ?? undefined}
    />
  );
}
