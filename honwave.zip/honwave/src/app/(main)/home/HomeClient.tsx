'use client';
import { useState } from 'react';
import Image from 'next/image';
import { usePlayerStore, PlayerTrack } from '@/lib/store';
import { getMoodConfig } from '@/lib/moodTagger';
import TrackCard from '@/components/TrackCard';

interface Track {
  id: string; title: string; mood: string; durationSec: number;
  coverUrl?: string | null; isNewDrop?: boolean; genreTag?: string | null;
  artist: { id: string; name: string }; album?: { id: string; title: string } | null;
}

interface Props {
  newDrops: Track[];
  trending: Track[];
  moodShelves: Record<string, Track[]>;
  allTracks: Track[];
  userName?: string;
}

const MOOD_LABELS: Record<string, string> = {
  CHILL: 'Night Drive 🌙',
  HYPE: 'Comeback Stage ⚡',
  HEARTBREAK: 'Signal Lost 💔',
};

function toPlayerTrack(t: Track): PlayerTrack {
  return { id: t.id, title: t.title, artistName: t.artist.name, coverUrl: t.coverUrl || '/mascot/portrait.png', mood: t.mood, durationSec: t.durationSec };
}

export default function HomeClient({ newDrops, trending, moodShelves, allTracks, userName }: Props) {
  const { play } = usePlayerStore();
  const [flashIdx, setFlashIdx] = useState(0);
  const flashTracks = trending.slice(0, 5);
  const flashTrack = flashTracks[flashIdx];
  const moodCfg = flashTrack ? getMoodConfig(flashTrack.mood) : null;

  function nextFlash() { setFlashIdx((i) => (i + 1) % flashTracks.length); }

  return (
    <div className="min-h-screen bg-void pb-4">
      {/* Hero header */}
      <div className="relative overflow-hidden px-5 pt-14 pb-8"
           style={{ background: 'radial-gradient(ellipse at 70% 0%, rgba(143,227,209,0.1) 0%, transparent 60%)' }}>
        <div className="text-xs text-glow tracking-[0.3em] uppercase mb-1">혼WAVE</div>
        <h1 className="font-serif text-3xl text-skin">
          {userName ? `Welcome back,\n${userName}` : 'For You'}
        </h1>
        {/* Mascot in hero */}
        <div className="absolute right-0 top-0 bottom-0 w-[160px] pointer-events-none select-none">
          <Image src="/mascot/chill.png" alt="HON" fill className="object-contain object-right-bottom"
            style={{ filter: 'drop-shadow(0 0 30px rgba(143,227,209,0.35))' }} />
        </div>
      </div>

      {/* Flash Card (swipeable Tinder-style suggestion) */}
      {flashTrack && moodCfg && (
        <div className="px-5 mb-8">
          <div className="text-xs text-skin/40 uppercase tracking-widest mb-3">Pick Your Next Track</div>
          <div className="relative rounded-2xl border border-border overflow-hidden p-5 flex gap-4 items-center"
               style={{ background: `linear-gradient(135deg, #13121C 0%, #1C1B29 100%), ${moodCfg.bgGradient}` }}>
            <div className="w-[80px] h-[100px] relative flex-shrink-0">
              <Image src={moodCfg.pose} alt="" fill className="object-contain object-bottom"
                style={{ filter: `${moodCfg.filter} drop-shadow(0 0 20px ${moodCfg.accent}80)` }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-bold tracking-widest mb-1" style={{ color: moodCfg.accent }}>
                {moodCfg.label.toUpperCase()}
              </div>
              <div className="font-serif text-xl text-skin truncate">{flashTrack.title}</div>
              <div className="text-xs text-skin/50 mb-3">{flashTrack.artist.name}</div>
              <button onClick={() => play(toPlayerTrack(flashTrack), flashTracks.map(toPlayerTrack))}
                className="px-4 py-1.5 rounded-full text-xs font-bold text-void"
                style={{ background: moodCfg.accent }}>
                ▶ Play
              </button>
            </div>
            <button onClick={nextFlash}
              className="absolute right-4 top-4 text-skin/30 hover:text-skin transition-colors text-lg">
              →
            </button>
          </div>
          {/* Dot indicators */}
          <div className="flex gap-1.5 justify-center mt-2.5">
            {flashTracks.map((_, i) => (
              <button key={i} onClick={() => setFlashIdx(i)}
                className={`h-1 rounded-full transition-all duration-300 ${i === flashIdx ? 'w-4 bg-glow' : 'w-1.5 bg-border'}`} />
            ))}
          </div>
        </div>
      )}

      {/* New Arc Drops */}
      {newDrops.length > 0 && (
        <section className="mb-8">
          <div className="flex items-center gap-2 px-5 mb-3">
            <span className="text-gold text-xs">◆</span>
            <span className="text-xs font-bold tracking-widest text-skin/60 uppercase">New Arc Drops</span>
          </div>
          <div className="flex gap-3 px-5 overflow-x-auto scrollbar-none">
            {newDrops.map(t => {
              const mc = getMoodConfig(t.mood);
              return (
                <button key={t.id} onClick={() => play(toPlayerTrack(t), newDrops.map(toPlayerTrack))}
                  className="flex-shrink-0 w-32 group">
                  <div className="relative w-32 h-32 rounded-xl overflow-hidden border border-border mb-2">
                    <Image src={t.coverUrl || '/mascot/portrait.png'} alt="" fill className="object-cover group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute bottom-2 right-2 w-2 h-2 rounded-full animate-pulseGlow"
                         style={{ background: mc.accent }} />
                  </div>
                  <div className="text-xs font-medium text-skin truncate">{t.title}</div>
                  <div className="text-[10px] text-skin/40 truncate">{t.artist.name}</div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Mood shelves */}
      {Object.entries(moodShelves).map(([mood, tracks]) => tracks.length > 0 && (
        <section key={mood} className="mb-8">
          <div className="flex items-center justify-between px-5 mb-3">
            <span className="text-xs font-bold tracking-widest text-skin/60 uppercase">{MOOD_LABELS[mood] || mood}</span>
            <span className="text-xs text-skin/30">See all</span>
          </div>
          <div className="space-y-1">
            {tracks.slice(0, 4).map(t => (
              <TrackCard key={t.id} track={t} queue={tracks.map(toPlayerTrack)} />
            ))}
          </div>
        </section>
      ))}

      {/* Trending */}
      <section className="mb-8 px-5">
        <div className="text-xs font-bold tracking-widest text-skin/60 uppercase mb-3">Trending OST</div>
        <div className="space-y-1">
          {trending.map((t, i) => (
            <div key={t.id} className="flex items-center gap-3">
              <span className="text-xs text-skin/20 w-4 flex-shrink-0 text-right">{i + 1}</span>
              <div className="flex-1">
                <TrackCard track={t} queue={trending.map(toPlayerTrack)} compact />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
