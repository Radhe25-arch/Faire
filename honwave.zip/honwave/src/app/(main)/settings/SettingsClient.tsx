'use client';
import { signOut } from 'next-auth/react';
import Image from 'next/image';

interface User { email: string; name?: string | null; plan: string; createdAt: string; }

const PREMIUM_PERKS = [
  'Unlimited Story exports — no watermark',
  'Animated GIF story export',
  'All 5 HON mood poses unlocked',
  'Exclusive seasonal mascot skins',
  'Offline downloads — unlimited',
  'High-quality 320kbps audio',
];

export default function SettingsClient({ user }: { user: User | null }) {
  if (!user) return null;
  const isPremium = user.plan === 'PREMIUM';

  return (
    <div className="min-h-screen bg-void px-5 pt-14 pb-4 space-y-6">
      {/* Profile */}
      <div className="flex items-center gap-4 py-4">
        <div className="relative w-16 h-16 rounded-full overflow-hidden border-2 border-glow/40">
          <Image src="/mascot/portrait.png" alt="" fill className="object-cover object-top" />
        </div>
        <div>
          <div className="font-serif text-xl text-skin">{user.name || 'Listener'}</div>
          <div className="text-xs text-skin/40">{user.email}</div>
          <div className={`text-[10px] font-bold tracking-widest uppercase mt-1 ${isPremium ? 'text-gold' : 'text-skin/30'}`}>
            {isPremium ? '★ Premium' : 'Free Tier'}
          </div>
        </div>
      </div>

      {/* Subscription card */}
      {!isPremium && (
        <div className="rounded-2xl border border-gold/30 p-5 space-y-4"
             style={{ background: 'linear-gradient(135deg, #1C1B29 0%, #13121C 100%)' }}>
          <div className="flex items-center gap-2">
            <span className="text-gold text-xl">★</span>
            <div>
              <div className="font-serif text-lg text-skin">혼WAVE Premium</div>
              <div className="text-xs text-skin/40">Unlock the full experience</div>
            </div>
          </div>
          <ul className="space-y-2">
            {PREMIUM_PERKS.map(p => (
              <li key={p} className="flex items-start gap-2 text-xs text-skin/70">
                <span className="text-glow mt-0.5 flex-shrink-0">✓</span>
                {p}
              </li>
            ))}
          </ul>
          <button className="w-full py-3 rounded-xl text-void font-bold text-sm bg-gold hover:brightness-110 transition-all">
            Upgrade — ₩9,900/mo
          </button>
        </div>
      )}

      {/* Mascot locked poses preview (FOMO hook) */}
      {!isPremium && (
        <div className="rounded-2xl border border-border p-5">
          <div className="text-xs font-bold tracking-widest text-skin/60 uppercase mb-3">HON Pose Collection</div>
          <div className="flex gap-2 overflow-x-auto scrollbar-none pb-2">
            {['chill', 'hype', 'heartbreak', 'power_up', 'rage'].map((p, i) => (
              <div key={p} className="relative flex-shrink-0 w-16 h-20 rounded-xl overflow-hidden border border-border">
                <Image src={`/mascot/${p}.png`} alt="" fill className="object-cover object-top" />
                {i > 1 && (
                  <div className="absolute inset-0 bg-void/70 backdrop-blur-sm flex items-center justify-center">
                    <span className="text-gold text-lg">🔒</span>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="text-[10px] text-skin/30 mt-2">3 poses locked — upgrade to unlock all moods</div>
        </div>
      )}

      {/* Settings rows */}
      <div className="space-y-1">
        {[
          { label: 'Audio Quality', value: isPremium ? '320kbps' : '128kbps' },
          { label: 'Downloads', value: isPremium ? 'Unlimited' : 'Not available' },
          { label: 'Story Exports Today', value: isPremium ? 'Unlimited' : '1 / 1 free' },
          { label: 'Notifications', value: 'On' },
        ].map(row => (
          <div key={row.label} className="flex items-center justify-between px-4 py-3.5 rounded-xl border border-border bg-panel">
            <span className="text-sm text-skin/70">{row.label}</span>
            <span className="text-xs text-skin/40">{row.value}</span>
          </div>
        ))}
      </div>

      {/* Logout */}
      <button onClick={() => signOut({ callbackUrl: '/login' })}
        className="w-full py-3 rounded-xl border border-border text-sm text-skin/40 hover:text-skin hover:border-skin/30 transition-all">
        Sign Out
      </button>

      <div className="text-center text-[10px] text-skin/20 pb-2">
        혼WAVE · Seoul · v0.1 · HON / 혼
      </div>
    </div>
  );
}
