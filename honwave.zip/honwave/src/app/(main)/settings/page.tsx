import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import SettingsClient from './SettingsClient';

export default async function SettingsPage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string;
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { email: true, name: true, plan: true, createdAt: true } });

  return <SettingsClient user={JSON.parse(JSON.stringify(user))} />;
}
