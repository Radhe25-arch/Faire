import { prisma } from '@/lib/prisma';
import Image from 'next/image';
import TrackCard from '@/components/TrackCard';
import { PlayerTrack } from '@/lib/store';
import { notFound } from 'next/navigation';

function toPlayerTrack(t: any): PlayerTrack {
  return { id: t.id, title: t.title, artistName: t.artist?.name || '', coverUrl: t.coverUrl || '/mascot/portrait.png', mood: t.mood, durationSec: t.durationSec };
}

export default async function ArtistPage({ params }: { params: { id: string } }) {
  const artist = await prisma.artist.findUnique({
    where: { id: params.id },
    include: {
      tracks: { include: { artist: true }, orderBy: { playCount: 'desc' }, take: 10 },
      albums: { orderBy: { releaseDate: 'desc' }, take: 6 },
    },
  });
  if (!artist) notFound();

  const queue = artist.tracks.map(toPlayerTrack);

  return (
    <div className="min-h-screen bg-void pb-4">
      {/* Banner */}
      <div className="relative h-64 overflow-hidden">
        <Image src={artist.bannerUrl || '/mascot/full_body.png'} alt="" fill className="object-cover object-top opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-void" />
        <div className="absolute bottom-4 left-5">
          <div className="text-xs text-glow tracking-widest uppercase mb-1">Artist</div>
          <h1 className="font-serif text-4xl text-skin">{artist.name}</h1>
        </div>
      </div>

      <div className="px-5 space-y-8 pt-4">
        {artist.bio && (
          <p className="text-sm text-skin/50 leading-relaxed">{artist.bio}</p>
        )}

        <section>
          <div className="text-xs font-bold tracking-widest text-skin/60 uppercase mb-3">Top Tracks</div>
          <div className="space-y-1">
            {artist.tracks.map(t => <TrackCard key={t.id} track={t} queue={queue} />)}
          </div>
        </section>

        {artist.albums.length > 0 && (
          <section>
            <div className="text-xs font-bold tracking-widest text-skin/60 uppercase mb-3">Discography</div>
            <div className="grid grid-cols-2 gap-3">
              {artist.albums.map(a => (
                <div key={a.id} className="rounded-xl border border-border overflow-hidden bg-panel">
                  <div className="relative w-full aspect-square">
                    <Image src={a.coverUrl || '/mascot/sitting.png'} alt="" fill className="object-cover" />
                  </div>
                  <div className="p-3">
                    <div className="text-sm font-medium text-skin truncate">{a.title}</div>
                    {a.releaseDate && <div className="text-[10px] text-skin/30">{new Date(a.releaseDate).getFullYear()}</div>}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
