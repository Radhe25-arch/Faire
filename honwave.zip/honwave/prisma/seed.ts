import { PrismaClient, Mood } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Genres
  const genreNames = ['K-pop', 'Anime OST', 'Lo-fi Manhwa', 'City Pop', 'Dark Trap', 'R&B'];
  const genres = await Promise.all(
    genreNames.map((name) => prisma.genre.upsert({ where: { name }, update: {}, create: { name } }))
  );

  // Demo user
  const passwordHash = await bcrypt.hash('password123', 10);
  const user = await prisma.user.upsert({
    where: { email: 'demo@honwave.app' },
    update: {},
    create: {
      email: 'demo@honwave.app',
      name: 'Trey',
      passwordHash,
      plan: 'FREE',
      genres: { create: [{ genreId: genres[0].id }, { genreId: genres[2].id }] },
    },
  });

  // Artist: HON himself, plus a couple others for variety
  const hon = await prisma.artist.create({
    data: {
      name: 'HON',
      bio: 'Born in Seoul. Lives in the noise to protect his silence. Producer — Dark Trap / R&B.',
      avatarUrl: '/mascot/portrait.png',
      bannerUrl: '/mascot/full_body.png',
    },
  });

  const nightCity = await prisma.artist.create({
    data: { name: 'NIGHT.CITY', bio: 'Lo-fi manhwa soundscapes.', avatarUrl: '/mascot/look_down.png' },
  });

  const album = await prisma.album.create({
    data: {
      title: 'Moon Glow EP',
      coverUrl: '/mascot/sitting.png',
      artistId: hon.id,
      releaseDate: new Date(),
    },
  });

  const trackData: { title: string; mood: Mood; isNewDrop: boolean; artistId: string; albumId?: string }[] = [
    { title: 'Crescent', mood: Mood.CHILL, isNewDrop: true, artistId: hon.id, albumId: album.id },
    { title: 'Empty Studio', mood: Mood.HEARTBREAK, isNewDrop: false, artistId: hon.id, albumId: album.id },
    { title: 'Seoul at 3AM', mood: Mood.CHILL, isNewDrop: false, artistId: nightCity.id },
    { title: 'Power Surge', mood: Mood.POWER_UP, isNewDrop: true, artistId: hon.id },
    { title: 'Static Rage', mood: Mood.RAGE, isNewDrop: false, artistId: hon.id },
    { title: 'Comeback Stage', mood: Mood.HYPE, isNewDrop: true, artistId: nightCity.id },
  ];

  for (const t of trackData) {
    await prisma.track.create({
      data: {
        title: t.title,
        mood: t.mood,
        isNewDrop: t.isNewDrop,
        artistId: t.artistId,
        albumId: t.albumId,
        coverUrl: '/mascot/portrait.png',
        durationSec: 180 + Math.floor(Math.random() * 60),
        genreTag: genreNames[Math.floor(Math.random() * genreNames.length)],
      },
    });
  }

  console.log('Seed complete. Demo login: demo@honwave.app / password123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
